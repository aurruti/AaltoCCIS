tcpdump -r capture.pcap -w not-iperf.pcap not tcp port 5201
